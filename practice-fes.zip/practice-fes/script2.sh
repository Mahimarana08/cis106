#!/bin/bash
read -p "What is your name " name
read -p "what is your fav color? " color
read -p "which programmimg language do you want to learn? " java
read -p "which programmimg language do you already know? " python
echo "Hello mahi! i hope yoy are doing fine today"
echo "I see that you like pink. that is my fav one too!"
echo "I see that you are intersested in learning java"
