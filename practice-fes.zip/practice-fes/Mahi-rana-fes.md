# final Submission

## Question 1
![q1](q1.1.png)
![q1](q1.2.png)

## Question 3
![q3](q3.2.png)